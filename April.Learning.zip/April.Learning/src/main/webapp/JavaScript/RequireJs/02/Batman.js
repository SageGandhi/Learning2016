Define('Batman',function(){console.log('Returns Factory Batman');return function(){console.log(["BatMan:You Are Testing My Patience."]);};});
/**Define Takes A Function That Function Will Return The Constructor*/
/**Other Way To Define('Module Name',function(){var ConstructorNamedOrNotNamed=function(){};return ConstructorNamedOrNotNamed;});*/