Require([ 'Batman', 'Joker' ], function(Batman) {
	console.log('*************************************');
	var BatInstance = new Batman();
	console.dir(BatInstance);
	console.log('*************************************');
});