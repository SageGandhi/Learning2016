Define('Joker',function(){
	console.log('Returns Factory Joker');
	var Joker=function(){console.log(["Joker:I don’t want to kill you! What would I do without you? Go back to ripping off mob dealers?" +
		"No, no, NO! No. You… you… complete me."]);
	};
	return Joker;
});