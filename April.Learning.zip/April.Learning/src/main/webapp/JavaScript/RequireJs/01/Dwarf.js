/**Creating Dwarf Constructor*/
var Dwarf=function(){console.log(["Tyrion:Once you’ve accepted your flaws, no one can use them against you.It's not easy being drunk all the time. If it were easy, everyone would do it."]);}
window.Application=window.Application||{};/**Creating Global NameSpace As Application With FallBack*/
window.Application.Dwarf=Dwarf;