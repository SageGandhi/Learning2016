/**Creating BatMan Constructor*/
var Batman=function(){console.log(["BatMan:All men have limits. They learn what they are and learn not to exceed them. I ignore mine.I wear a mask. And that mask, it's not to hide who I am, but to create what I am.You Are Testing My Patience."]);}
window.Application=window.Application||{};/**Creating Global NameSpace As Application With FallBack*/
window.Application.Batman=Batman;