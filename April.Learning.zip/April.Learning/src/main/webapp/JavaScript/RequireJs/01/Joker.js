/**Creating Joker Constructor*/
var Joker=function(){console.log(["Joker:See, I'm not a monster. I'm just ahead of the curve.Why so serious?Do I really look like a guy with a plan? You know what I am? I'm a dog chasing cars. I wouldn't know what to do with one if I caught it! You know, I just... *do* things."]);}
window.Application=window.Application||{};/**Creating Global NameSpace As Application With FallBack*/
window.Application.Joker=Joker;