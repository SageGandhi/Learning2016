/**Creating MrRobot Constructor*/
var MrRobot=function(){console.log(["MrRobot:If they lock me up, the kind of door they close don’t matter.Every hacker loves attention."]);}
window.Application=window.Application||{};/**Creating Global NameSpace As Application With FallBack*/
window.Application.MrRobot=MrRobot;