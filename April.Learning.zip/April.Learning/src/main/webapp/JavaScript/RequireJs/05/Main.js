/**Now Requires Takes CallBack Function*/
Require(['Batman','MrRobot','Dwarf','Joker'],function(Batman,MrRobot,Dwarf,Joker){
	var BatInstance=new Batman(),MrRobotInstance=new MrRobot(),
		DwarfInstance=new Dwarf(),JokerInstance=new Joker();
});